const data = [
                {
                    index: 1,
                    title: 'Peace of mind',
                    score: .1,
                    magnitude: 5,  
                },
                {
                    index: 2,
                    title: 'Heaven',
                    score: .4,
                    magnitude: 2.9,  
                },
                {
                    index: 3,
                    title: 'SOS',
                    score: .4,
                    magnitude: 5.6,  
                },
                {
                    index: 4,
                    title: 'Tough love',
                    score: .4,
                    magnitude: 2.7,  
                },
                {
                    index: 5,
                    title: 'Bad reputation',
                    score: 0,
                    magnitude: 4.1,  
                },
                {
                    index: 6,
                    title: 'Ain\'t a thing',
                    score: -.1,
                    magnitude: 3.9,  
                },
                {
                    index: 7,
                    title: 'Hold the line',
                    score: -.1,
                    magnitude: 3.3,  
                },
                {
                    index: 8,
                    title: 'Freak',
                    score: -.4,
                    magnitude: 4.9,  
                },
                {
                    index: 9,
                    title: 'Excuse me Mr. Sir',
                    score: -.3,
                    magnitude: 2.3,  
                },
                {
                    index: 10,
                    title: 'Heart upon my sleave',
                    score: -.1,
                    magnitude: 4,  
                },
                {
                    index: 11,
                    title: 'Never leave me',
                    score: .3,
                    magnitude: 4.4,  
                },
                {
                    index: 12,
                    title: 'Fades away',
                    score: -.4,
                    magnitude: 3,  
                },
            ]

const bezierData = [
    [.1, 5, .4, 2.9, .4, 5.6, .4, 2.7],
    [.4, 2.7, 0, 4.1, -.1, 3.9, -.1, 3.3],
    [-.1, 3.3, -.4, 4.9, -.3, 2.3, -.1, 4],
    [-.1, 4, .3, 4.4, -.4, 3, -.7, 6.8]
]